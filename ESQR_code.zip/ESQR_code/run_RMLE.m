function [mos_clean,prob_clean]=run_RMLE(vote)
     g=Solve_RMLE_optimization_problem(vote);
     mos_clean=zeros(size(vote,1),1);

     % g is an array, make it a matrix with 5 colunms
     for f=1:length(g)/5
          prob_clean(f,:)=g( (1+5*(f-1)):(5*f))';
          mos_clean(f)=sum(prob_clean(f,:).*(1:5));
     end
end

%%

function [p]=Solve_RMLE_optimization_problem(X)
         
   % computing  the Regularized  likelyhood function
          I=length(X(:,1));
          J=length(X(1,:));
          
         fun=@(p) compute_regularized_likelyhood(p,X);  
         
         
     % setting the initial weights to the empirical fractions 
          K=1; 
          p_0=zeros(5*(I),1);
          for i=1:I
             for j=1:5
                 p_0(K)=sum(X(i,:)==j)/length(X(i,:));
                 K=K+1;
             end
          end
         
     % boundary constraints         
         lb=zeros(1,5*(I));
         ub=ones(1,5*(I));
         
     % setting the sum to 1 constraint
        Aeq=zeros(I,5*(I));
        beq=ones(I,1);
        for i=1:I
            Aeq(i,(1+5*(i-1)):(5+5*(i-1)))=[1 1 1 1 1];
        end
       

        % solving the optimization problem
        options = optimoptions('fmincon','Display','off','Algorithm','sqp','MaxFunctionEvaluations',6*10^10,'MaxIterations',50);
        d = fmincon(fun,p_0',[],[],Aeq,beq,lb,ub,[],options);
        p=d(1:5*I)';
      
end 

%%
function L=compute_regularized_likelyhood(p,X)
         
         % Log-likelihood component 
         L=0;
         I=length(X(:,1));
         J=length(X(1,:));
         ep=10^(-16);
         for i=1:I
             for j=1:J
                 L=L+log( p(5*(i-1)+X(i,j))+ep);               
             end 
         end 
          
         % regularization component 
          K=1;
          f=zeros(1,5*(I));
          for i=1:(I)
             for j=1:5
                 f(K)=sum(X(i,:)==j)/length(X(i,:));
                 K=K+1;
             end
          end
         f=-log(f+ep);

         % the whole RMLE objective function
         L=-(L-(5*I/(2*J))*sum(f.*p(1:5*I)));
end 