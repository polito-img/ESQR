function corr_coef=fisher_z_transformation_v2(V)
          for i=1:size(V,2)
             z=atanh(V(:,i));
             z=mean(z);
             corr_coef(i)=tanh(z);     
          end
end