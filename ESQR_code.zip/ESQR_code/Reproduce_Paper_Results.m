clear all; 
close all; 

% Reading the votes from the 3 VQEG datasets

columnNames={'sequence','PSNRFrameAligned','Votes'};
metrics={'PSNRFrameAligned','SSIMFrameAligned','MSSSIMFrameAligned','VIFPAligned','VMAF061FrameAligned'};
num_columns=length(columnNames);
T = readtable('all_vqeg_hdtv_scores_new_temporal_alignement_v2_noSingleFrames.csv','Delimiter',';','ReadVariableNames',true);
data_sizes=size(T);
data=T(logical(1:data_sizes(1)),columnNames);
data=rmmissing(data);
data=data(:,{columnNames{1:num_columns}});
cleaned_data=data(:,{columnNames{1:num_columns}});
cleaned_data=cleaned_data(:,[1 3]);
Votes=str2num(cell2mat(cleaned_data.Votes));
Vqeg_votes=Votes;

% Spliting the 3 VQEG-HD datasets
vqeg_hd1_id=contains(cleaned_data.sequence,'vqeghd1');
vqeg_hd3_id=contains(cleaned_data.sequence,'vqeghd3'); 
vqeg_hd5_id=contains(cleaned_data.sequence,'hdtv5'); 

% reading the votes of the PVSs in the  Netflix pubblic db
T_netflix = readtable('NETFLIX_dataset.xlsx','ReadVariableNames',true);
votes_netflix=table2array(T_netflix(:,9:34));


% saving the ratings of the four datasets 
vqeg_hd1=Votes(vqeg_hd1_id,:);
vqeg_hd3=Votes(vqeg_hd3_id,:);
vqeg_hd5=Votes(vqeg_hd5_id,:);
netflix_votes=votes_netflix;

 % saving the ratings of each of the 4 datasets to then load them
 % automatically when required

save('netflix_votes.mat','netflix_votes');
save('vqeg_hd1.mat','vqeg_hd1');
save('vqeg_hd3.mat','vqeg_hd3');
save('vqeg_hd5.mat','vqeg_hd5');

%% Experiments on the ESQR robustness to noise 

% datasets name 
dataset_names={'netflix_votes.mat','vqeg_hd1.mat','vqeg_hd3.mat','vqeg_hd5.mat'};

% setting the ploting parameters
set(0, 'defaultAxesFontSize', 35);
set(0, 'defaultTextFontSize', 35);
set(gca,'FontSize',35);
set(0, 'DefaultLineLineWidth', 3);
rng(1)

%% CASE 1: Adding spammer annotators to a clean db  

% repeat the experiments on each dataset
for id_data=1:length(dataset_names)
   
   % print current dataset name to see the progress
   fprintf('Current dataset: %s',dataset_names{id_data})

   % choosing the current dataset
   dataset=load(dataset_names{id_data});
   vote=struct2array(dataset); 

   % compute the ground truth quality.
   RMLE_ref=run_RMLE(vote);
   MOS_ref = mean(vote,2);
   SUREAL_ref= perform_SUREAL(vote,10^(-8));
   BT500_ref= perform_BT_500(vote,.05,.30);
   ZREC_ref=perform_ZREC(vote);
   ESQR_ref=run_ESQR(vote);
   
   % declare the spcace to contain the RMSE of each method 
    RMSE_RMLE=[];
    RMSE_SUREAL=[];
    RMSE_BT500=[];
    RMSE_MOS=[];
    RMSE_ZREC=[];
    RMSE_ESQR=[];

    % set the maximum number of spammer annotators to be added 
    max_num_noisy_subj=10;
    
    % setting the number of seed
    Num_seed=30;


    for s=1:max_num_noisy_subj
     
       for seed=1:Num_seed
            
            % setting a new seed
            rng(seed)

            % save the clean db
            data=vote;
            % add to it the randomly generated opinion scores for s spammer
            % annotators
            noisy_data=[data,reshape(randsample(1:5,s*size(data,1),true),size(data,1),s)];

            % run each quality recovery method on the noisy db and compare
            % the result to the ref value obtained on the clean db
            RMSE_RMLE(seed,s)=rmse(run_RMLE(noisy_data),RMLE_ref);
            RMSE_SUREAL(seed,s)=rmse(perform_SUREAL(noisy_data,10^(-8)),SUREAL_ref);
            RMSE_BT500(seed,s)=rmse(perform_BT_500(noisy_data,.05,.30),BT500_ref);
            RMSE_MOS(seed,s)=rmse(mean(noisy_data,2),MOS_ref);
            RMSE_ZREC(seed,s)=rmse(perform_ZREC(noisy_data),ZREC_ref);        
            RMSE_ESQR(seed,s)=rmse(run_ESQR(noisy_data),ESQR_ref);
      end
   end

  % averaging the RMSE over the number of seeds
  RMSE_RMLE=mean(RMSE_RMLE,1);
  RMSE_SUREAL=mean(RMSE_SUREAL,1);
  RMSE_BT500=mean(RMSE_BT500,1);
  RMSE_MOS=mean(RMSE_MOS,1);
  RMSE_ZREC=mean(RMSE_ZREC,1);
  RMSE_ESQR=mean(RMSE_ESQR,1);


 % ploting the results
 my_fig=figure;
 set(gcf,'units','points','position',[0,0,1000,900])

 plot(0:max_num_noisy_subj,[0,RMSE_MOS],LineWidth=3)
 hold on 
 plot(0:max_num_noisy_subj,[0,RMSE_BT500],LineWidth=3)
 hold on 
 plot(0:max_num_noisy_subj,[0,RMSE_ZREC],LineWidth=3)
 hold on 
 plot(0:max_num_noisy_subj,[0,RMSE_SUREAL],LineWidth=3)
 hold on 
 plot(1:max_num_noisy_subj,RMSE_RMLE,LineWidth=3)
 hold on 
 plot(0:max_num_noisy_subj,[0,RMSE_ESQR],LineWidth=3)
 as=gca;
 as.GridAlpha=1;
 box on 
 grid on
 xlabel('Number of corrupted subjects')
 ylabel('RMSE')
 xlim([1, max_num_noisy_subj])
 xticks(1:max_num_noisy_subj)
 legend('MOS', 'BT500','ZREC','SUREAL','RMLE','ESQR',Location='northwest')
 saveas(my_fig,strcat('RMSE_case_1_',extractBefore(dataset_names{id_data},'.mat'),'.png'));
end

%% CASE 2: robustness to noise due to subjects fatigue 

for id_data=1:length(dataset_names)
   
   % print current dataset name to see the progress
   fprintf('Current dataset: %s',dataset_names{id_data})

   % load the current dataset
   dataset=load(dataset_names{id_data});
   vote=struct2array(dataset);

   % set the number of seeds
   Num_seed=30;
   
   % set the percentage of noisy rating due to fatigue or distraction
   percentages=[0 .01 .02 .03 .04 .05 .06 .07 .08  .09 .1];

   RMSE_RMLE=[];
   RMSE_SUREAL=[];
   RMSE_BT500=[];
   RMSE_MOS=[];
   RMSE_ZREC=[];
   RMSE_ESQR=[];

   RMLE_ref=run_RMLE(vote);
   MOS_ref = mean(vote,2);
   SUREAL_ref= perform_SUREAL(vote,10^(-8));
   BT500_ref= perform_BT_500(vote,.05,.30);
   ZREC_ref=perform_ZREC(vote);   
   ESQR_ref=run_ESQR(vote);

 for seed=1:Num_seed
    rng(seed);
    
    for i=1:length(percentages)
        num_changes=round(size(vote,1)*percentages(i));
        data=vote;
        for  j=(round(size(vote,2)*0)+1):size(vote,2)
             noisy_ind=randsample(1:size(vote,1),num_changes);
             data(noisy_ind,j)=randsample(1:5,num_changes,true);
        end
        RMSE_RMLE(i,seed)=rmse(run_RMLE(data),RMLE_ref);
        RMSE_SUREAL(i,seed)=rmse(perform_SUREAL(data,10^(-8)),SUREAL_ref);
        RMSE_BT500(i,seed)=rmse(perform_BT_500(data,.05,.30),BT500_ref);
        RMSE_MOS(i,seed)=rmse(mean(data,2),MOS_ref);
        RMSE_ESQR(i,seed)=rmse(run_ESQR(data),ESQR_ref);
        RMSE_ZREC(i,seed)=rmse(perform_ZREC(data),ZREC_ref);        
    end
 end
 RMSE_RMLE=mean(RMSE_RMLE,2);
 RMSE_SUREAL=mean(RMSE_SUREAL,2);
 RMSE_BT500=mean(RMSE_BT500,2);
 RMSE_MOS=mean(RMSE_MOS,2);
 RMSE_ZREC=mean(RMSE_ZREC,2);
 RMSE_ESQR=mean(RMSE_ESQR,2);


 % ploting the results 
 my_fig=figure;
 set(gcf,'units','points','position',[0,0,1000,900])
 plot(percentages,RMSE_MOS,LineWidth=3)
 hold on 
 plot(percentages,RMSE_BT500,LineWidth=3)
 hold on 
 plot(percentages,RMSE_ZREC,LineWidth=3)
 hold on 
 plot(percentages,RMSE_SUREAL,LineWidth=3)
 hold on 
 plot(percentages,RMSE_RMLE,LineWidth=3)
 hold on 
 plot(percentages,RMSE_ESQR,LineWidth=3)
 as=gca;
 as.GridAlpha=1;
 box on 
 grid on
 xlabel('Probability of scoring inaccurately')
 ylabel('RMSE')
 xlim([0, 0.1])
 xticks(percentages)
 legend('MOS', 'BT500','ZREC','SUREAL','RMLE','ESQR',Location='northwest')
 saveas(my_fig,strcat('RMSE_case_2_',extractBefore(dataset_names{id_data},'.mat'),'.png'));
end 


%% Experiments on the  Comparison of CI sizes for lab datasets
dataset_names={'netflix_votes_complete.mat','vqeg_hd1.mat','vqeg_hd3.mat','vqeg_hd5.mat'};

PLCC=[];
SROCC=[];
RMSE=[];
CI_SIZE=[];

for i=1:length(dataset_names)
    data=load(dataset_names{i});
    data=struct2array(data);
    
    % MOS
    SS_MOS=std(data');
    MOS=mean(data,2);
    CI_size_MOS=mean(2*1.96*SS_MOS/sqrt(size(data,2)));

    % BT500
    [BT500,out_sub]=perform_BT_500(data,.05,.3);
    SS_BT500=std((data(:,~out_sub))');
    CI_size_BT500=mean(2*1.96*SS_BT500/sqrt(size(data(:,~out_sub),2)));

    %ZREC 
    [Q_ZREC,CI_size_ZREC]=perform_ZREC(data);

    %SUREAL 
    [Q_SUREAL,~,~,CI_SURAL]=perform_SUREAL(data,10^(-8));
    CI_size_SUREAL=mean(CI_SURAL(:,2)-CI_SURAL(:,1));

    %RMLE 
    [q,w]=run_RMLE(data);
    Q_RMLE=w*[1 2 3 4 5]';
    stds=compute_std(w);
    q_CI=[q-1.96*stds'/sqrt(size(data,2)), q+1.96*stds'/sqrt(size(data,2))];
    CI_size_RMLE=mean(q_CI(:,2)-q_CI(:,1));

    % ESQR
    [Q_ESQR,CI_size_ESQR]=run_ESQR(data);

    % CI_Size for the current dataset
    CI_SIZE(i,:)=[CI_size_MOS,CI_size_BT500,CI_size_ZREC,CI_size_SUREAL,CI_size_RMLE,CI_size_ESQR];

    %compare recovered qualities
    Qs=[MOS,BT500,Q_ZREC,Q_SUREAL,Q_RMLE,Q_ESQR];
    
    for j=1:(size(Qs,2)-1)
        RMSE(j,i)=rmse(Qs(:,j),Qs(:,end));
        PLCC(j,i)=corr(Qs(:,j),Qs(:,end));
        SROCC(j,i)=corr(Qs(:,j),Qs(:,end),'type','Spearman');
    end

end
%%

PLCC=round(PLCC,3)
SROCC=round(SROCC,3)
RMSE=round(RMSE,3)
CI_SIZE=(round(CI_SIZE,3))'

Methods=({'MOS', 'BT500', 'ZREC', 'SUREAL', 'RMLE'})';
NTFx_PUB=(PLCC(:,1));
VQEG_HD1=(PLCC(:,2));
VQEG_HD3=(PLCC(:,3));
VQEG_HD5=(PLCC(:,4));
PLCC_table=table(Methods,NTFx_PUB,VQEG_HD1,VQEG_HD3,VQEG_HD5)

NTFx_PUB=(SROCC(:,1));
VQEG_HD1=(SROCC(:,2));
VQEG_HD3=(SROCC(:,3));
VQEG_HD5=(SROCC(:,4));
SROCC_table=table(Methods,NTFx_PUB,VQEG_HD1,VQEG_HD3,VQEG_HD5)

NTFx_PUB=(RMSE(:,1));
VQEG_HD1=(RMSE(:,2));
VQEG_HD3=(RMSE(:,3));
VQEG_HD5=(RMSE(:,4));
RMSE_table=table(Methods,NTFx_PUB,VQEG_HD1,VQEG_HD3,VQEG_HD5)

Methods=({'MOS', 'BT500', 'ZREC', 'SUREAL', 'RMLE', 'ESQR'})';
NTFx_PUB=(CI_SIZE(:,1));
VQEG_HD1=(CI_SIZE(:,2));
VQEG_HD3=(CI_SIZE(:,3));
VQEG_HD5=(CI_SIZE(:,4));
CI_SIZE_table=table(Methods,NTFx_PUB,VQEG_HD1,VQEG_HD3,VQEG_HD5)



%% Example of peculiar PVS (#63 of Netflix Pub db) 
Q_ESQR=run_ESQR(netflix_votes);
MOS=mean(netflix_votes,2);

figure 
hist(netflix_votes(63,:));
xlim([1 5]);
title(sprintf('MOS: %.2f, ESQR: %.2f',MOS(63), Q_ESQR(63)));
xlabel('Opinion scores')
ylabel('Frequency')
 as=gca;
 as.GridAlpha=1;
 box on 
 grid on


%% Experiments assessing the accuracy in estimating the CIs 

% setting an intital seed
rng(100)

% space to save the Delta and rho values
Rho=[];
Delta=[];

pos=0;
for seed=round(linspace(1000,100000000,30)) % to spaced the 30 seeds
    pos=pos+1;
    
    % simulate the current dataset
    [simulated_votes, gt_CIs]=simulating_ny_votes(seed);
    Q=gt_CIs(:,1)+(gt_CIs(:,2)-gt_CIs(:,1))/2;
    
    % MOS
    SS_MOS=(std(simulated_votes'))';
    MOS=mean(simulated_votes,2);
    CI_MOS=[MOS,MOS]+1.96*[-SS_MOS/sqrt(size(simulated_votes,2)),SS_MOS/sqrt(size(simulated_votes,2))];

    % BT500
    [BT500,out_sub]=perform_BT_500(simulated_votes,.05,.3);
    SS_BT500=(std((simulated_votes(:,~out_sub))'))';
    CI_BT500=[BT500,BT500]+1.96*[-SS_BT500/sqrt(size(simulated_votes,2)),SS_BT500/sqrt(size(simulated_votes,2))];

    %ZREC 
    CI_ZREC=[];
    [Q_ZREC,CI_size_ZREC,CI_ZREC]=perform_ZREC(simulated_votes);

    %SUREAL 
    [Q_SUREAL,~,~,CI_SUREAL]=perform_SUREAL(simulated_votes,10^(-8));

    %RMLE 
    [q,w]=run_RMLE(simulated_votes);
    Q_RMLE=w*[1 2 3 4 5]';
    stds=compute_std(w);
    CI_RMLE=[q-1.96*stds'/sqrt(size(simulated_votes,2)), q+1.96*stds'/sqrt(size(simulated_votes,2))];

    % ESQR
    [Q_ESQR,CI_size_ESQR,CI_ESQR]=run_ESQR(simulated_votes);
     
L_CI_estimated=[];
L_CI_gt=[];
Center_estimated=[];
Center_gt=[];
rho=[];
delta=[];
L_CI_estimated=[CI_MOS(:,2)-CI_MOS(:,1),CI_BT500(:,2)-CI_BT500(:,1),CI_ZREC(:,2)-CI_ZREC(:,1),CI_SUREAL(:,2)-CI_SUREAL(:,1),CI_RMLE(:,2)-CI_RMLE(:,1),CI_ESQR(:,2)-CI_ESQR(:,1)];
L_CI_gt=gt_CIs(:,2)-gt_CIs(:,1);
Center_estimated=[MOS,BT500,Q_ZREC,Q_SUREAL,Q_RMLE,Q_ESQR];
Center_gt=Q;

for i=1:6
    rho(:,i)=L_CI_estimated(:,i)./L_CI_gt;
    delta(:,i)=Center_estimated(:,i)-Center_gt;
end


Rho(:,:,pos)=rho;
Delta(:,:,pos)=delta;
end

% average the results over all simulated datasets
delta=mean(Delta,3);
rho=mean(Rho,3);

%% save the results in a csv table
MOS=[]; BT500=[]; ZREC=[]; SUREAL=[]; RMLE=[]; ESQR=[];
T=table(MOS,BT500,ZREC,SUREAL,RMLE,ESQR);
Delta_m=mean(abs(delta));
Rho_m= mean(rho);
T.MOS(1)=Delta_m(1); T.MOS(2)=Rho_m(1);
T.BT500(1)=Delta_m(2); T.BT500(2)=Rho_m(2);
T.ZREC(1)=Delta_m(3); T.ZREC(2)=Rho_m(3);
T.SUREAL(1)=Delta_m(4); T.SUREAL(2)=Rho_m(4);
T.RMLE(1)=Delta_m(5); T.RMLE(2)=Rho_m(5);
T.ESQR(1)=Delta_m(6); T.ESQR(2)=Rho_m(6);
writetable(T,'results_simulation_CIs.csv')
T


%%  Experiments on datasets with a sparse matrix of ratings: the first dataset: MovieLens 1M

% reading the dataset and saving the sparse matrix of ratings 
data_file=readtable('CroundSourcing.txt','Delimiter','::','ReadVariableNames',false);
head(data_file)
id_subjects=unique(data_file.Var1);
id_media=unique(data_file.Var2);

pos=1;
for i=id_media'
    labels{pos}=strcat('media_',num2str(i));
    pos=pos+1;
end

Ratings_mat=NaN(length(id_media),length(id_subjects));
for ii=1:size(data_file,1)
    line=table2array(data_file(ii,1:3));
    pos_subject=line(1); 
    rating=line(3);
    pos_media=0; 

    for jj=1:length(id_media)
        if id_media(jj)==line(2)
            pos_media=jj;
            break
        end
    end
    
    Ratings_mat(pos_media,pos_subject)=rating;
    
end

writetable(table(Ratings_mat),'CroundSourcing_ratings.csv');

%% working only with subjects that have rated at leats 100 stimuli. 
select_ratings_mat=[];
assigned=~isnan(Ratings_mat);
id_selected_media=sum(assigned,2)>100;
id_selected_subjects=sum(assigned,1)>100;

%
select_ratings_mat=Ratings_mat(id_selected_media,id_selected_subjects);

% MOS
SS_MOS_CS=nanstd(select_ratings_mat');
MOS_CS=nanmean(select_ratings_mat,2);
nun_ratings=sum(~isnan(select_ratings_mat),2);
CI_size_MOS_CS=mean( 2*1.96*(SS_MOS_CS./sqrt(nun_ratings')));

% ESQR
[Q_ESQR,CI_SIZE_CS_ESQR]=run_ESQR_sparse(select_ratings_mat);

% SUREAL
[Q_SUREAL,~,~,CI_SURAL]=perform_SUREAL_CS(select_ratings_mat,10^(-8));
CI_size_SUREAL=mean(CI_SURAL(:,2)-CI_SURAL(:,1));

MovieLens(1)=CI_size_MOS_CS;
MovieLens(2)=CI_size_SUREAL;
MovieLens(3)=CI_SIZE_CS_ESQR;


%% recovered quality comparison on the MovieLens db 

  set(0, 'defaultAxesFontSize', 44);
  set(0, 'defaultTextFontSize', 44);
  set(gca,'FontSize',44);
  set(0, 'DefaultLineLineWidth', 3);

  figure
  plot(Q_ESQR,Q_SUREAL,'k.','MarkerSize',20)
  hold on 
  plot([1 5],[1 5])
  grid on 
  box on 
  ylim([1 5])
  xlim([1 5])
  xlabel('q_{ESQR}');
  ylabel('q_{SUREAL}');
  xticks([1 2 3 4 5])
  yticks([1 2 3 4 5])
  as=gca;
  as.GridAlpha=1;
  Stats(3)=rmse(Q_ESQR,Q_SUREAL);
  Stats(1)=corr(Q_ESQR,Q_SUREAL);
  Stats(2)=corr(Q_ESQR,Q_SUREAL,'type','Spearman');
  title(sprintf('RMSE: %.2f, PLCC: %.2f, SROCC:  %.2f',Stats(3),Stats(1),Stats(2)))
   
%% Histogram of the stimulus with the highest difference 
 
  set(0, 'defaultAxesFontSize', 44);
  set(0, 'defaultTextFontSize', 44);
  set(gca,'FontSize',44);
  set(0, 'DefaultLineLineWidth', 3);


 [M,K]=max(abs(Q_ESQR-Q_SUREAL));
 figure
 hist(select_ratings_mat(K,:))
  grid on 
  box on 
  xlim([1 5])
  xticks([1 2 3 4 5])
  xlabel('Opinion Scores');
  ylabel('Frequency');
  as=gca;
  as.GridAlpha=1;
  title(sprintf('MOS: %.2f, SUREAL: %.2f, ESQR: %.2f',MOS_CS(K),Q_SUREAL(K),Q_ESQR(K)))



%%  second dataset: KoNViD-1k

% reading the sparse matrix of ratings
data_file_2=readtable('KoNViD_1k_subjective.csv','ReadVariableNames',true);
id=isnan(data_file_2.x_worker_id);
id_subjects=unique(data_file_2.x_worker_id(~id));
id=isnan(data_file_2.flickr_id);
id_seq=unique(data_file_2.flickr_id(~id));

n_sub=length(id_subjects);
n_seq=length(id_seq);
Ratings=nan(n_seq,n_sub);

for i=1:size(data_file_2,1)
    current_seq=data_file_2.flickr_id(i);
    current_subject=data_file_2.x_worker_id(i);

    pos_seq=find(id_seq==current_seq);
    pos_subj=find(id_subjects==current_subject);
    r=data_file_2.scale(i);

    if ~isempty(pos_seq) && ~isempty(pos_subj) && ~isnan(r)
       Ratings(pos_seq,pos_subj)=r;
    end
end

% MOS
Ratings=Ratings(5:end,:);
SS_MOS_CS=nanstd(Ratings');
MOS_CS=nanmean(Ratings,2);
nun_ratings=sum(~isnan(Ratings),2);
CI_size_MOS_CS=mean( 2*1.96*(SS_MOS_CS./sqrt(nun_ratings')));

% QC2AE
[Q_ESQR,CI_SIZE_CS_ESQR]=run_ESQR_sparse(Ratings);

% SUREAL
[Q_SUREAL,~,~,CI_SURAL]=perform_SUREAL_CS(Ratings,10^(-8));
CI_size_SUREAL=mean(CI_SURAL(:,2)-CI_SURAL(:,1));

KoNViD(1)=CI_size_MOS_CS;
KoNViD(2)=CI_size_SUREAL;
KoNViD(3)=CI_SIZE_CS_ESQR;


 %% quality comparison  
  set(0, 'defaultAxesFontSize', 44);
  set(0, 'defaultTextFontSize', 44);
  set(gca,'FontSize',44);
  set(0, 'DefaultLineLineWidth', 3);

  figure
  plot(Q_ESQR,Q_SUREAL,'k.','MarkerSize',20)
  hold on 
  plot([1 5],[1 5])
  grid on 
  box on 
  ylim([1 5])
  xlim([1 5])
  xlabel('q_{ESQR}');
  ylabel('q_{SUREAL}');
  xticks([1 2 3 4 5])
  yticks([1 2 3 4 5])
  as=gca;
  as.GridAlpha=1;
  Stats(3)=rmse(Q_ESQR,Q_SUREAL);
  Stats(1)=corr(Q_ESQR,Q_SUREAL);
  Stats(2)=corr(Q_ESQR,Q_SUREAL,'type','Spearman');
  title(sprintf('RMSE: %.2f, PLCC: %.2f, SROCC:  %.2f',Stats(3),Stats(1),Stats(2)))
   
 %% Histogram of the stimulus with the highest difference 

  set(0, 'defaultAxesFontSize', 44);
  set(0, 'defaultTextFontSize', 44);
  set(gca,'FontSize',44);
  set(0, 'DefaultLineLineWidth', 3);

 [M,K]=max(abs(Q_ESQR-Q_SUREAL));
 figure
 hist(Ratings(K,:))
  grid on 
  box on 
  xlim([1 5])
  xticks([1 2 3 4 5])
  xlabel('Opinion Scores');
  ylabel('Frequency');
  as=gca;
  as.GridAlpha=1;
  
  title(sprintf('MOS: %.2f, SUREAL: %.2f, ESQR: %.2f',MOS_CS(K),Q_SUREAL(K),Q_ESQR(K)))

%% visualizing CI results on the two datasets
MovieLens=MovieLens';
KoNViD=KoNViD';
Methods={'MOS','SUREAL','ESQR'}';
CI_sparse_mat=table(Methods,KoNViD,MovieLens)

%% save the loaded sparse matrices of ratings for the next experiment
MovieLens_data=select_ratings_mat;
KoNViD_data=Ratings;

%% Robustness to noise on the MovieLens dataset 

RMSE_S=[];
RMSE_Q=[];

perc=[0 .1 .2 .3 .4 .5];
Q_SUREAL=perform_SUREAL_CS(MovieLens_data,10^(-8));
Q_CS=run_ESQR_sparse(MovieLens_data);


for i=1:length(perc)
     Data=MovieLens_data;
     for ii=1:size(Data,1)
          for jj=1:size(Data,2)
              if ~isnan(Data(ii,jj))
                  rd=binornd(1,perc(i));
                  Data(ii,jj)=Data(ii,jj)*(1-rd)+randsample(5,1)*(rd);
              end
          end
     end
     Data(Data==0)=nan;

     [Q_SUREAL_i,bias,inc,CI_SURAL]=perform_SUREAL_CS(Data,10^(-8));
     [Q_CS_i,CI_SIZE_CS_QC2AE]=QC2AE_crowdSourcing(Data);
     RMSE_Q(i)=rmse(Q_CS_i,Q_CS);
     RMSE_S(i)=rmse(Q_SUREAL_i,Q_SUREAL);
     
end

 my_fig=figure;
 set(gcf,'units','points','position',[0,0,1000,900]) 
 plot(perc,RMSE_S,LineWidth=3)
 hold on 
 plot(perc,RMSE_Q,LineWidth=3)
 as=gca;
 as.GridAlpha=1;
 box on 
 grid on
 xlabel('Fraction of noisy ratings')
 ylabel('RMSE')
 xlim([0 .5])
 xticks(perc)
 legend('SUREAL','ESQR',Location='northwest')

%% Robustness to noise on the KoNViD dataset 


RMSE_S=[];
RMSE_Q=[];

perc=[0 .1 .2 .3 .4 .5];
[Q_SUREAL,bias,inc,CI_SURAL]=perform_SUREAL_CS(KoNViD_data,10^(-8));
[Q_CS,CI_SIZE_CS_QC2AE]=run_ESQR_sparse(KoNViD_data);


for i=1:length(perc)
     Data=KoNViD_data;
     for ii=1:size(Data,1)
          for jj=1:size(Data,2)
              if ~isnan(Data(ii,jj))
                  rd=binornd(1,perc(i));
                  Data(ii,jj)=Data(ii,jj)*(1-rd)+randsample(5,1)*(rd);
              end
          end
     end
     Data(Data==0)=nan;

     [Q_SUREAL_i,bias,inc,CI_SURAL]=perform_SUREAL_CS(Data,10^(-8));
     [Q_CS_i,CI_SIZE_CS_QC2AE]=QC2AE_crowdSourcing(Data);
     RMSE_Q(i)=rmse(Q_CS_i,Q_CS);
     RMSE_S(i)=rmse(Q_SUREAL_i,Q_SUREAL);
     
end

 my_fig=figure;
 set(gcf,'units','points','position',[0,0,1000,900]) 
 plot(perc,RMSE_S,LineWidth=3)
 hold on 
 plot(perc,RMSE_Q,LineWidth=3)
 as=gca;
 as.GridAlpha=1;
 box on 
 grid on
 xlabel('Fraction of noisy ratings')
 ylabel('RMSE')
 xlim([0 .5])
 xticks(perc)
 legend('SUREAL','ESQR',Location='northwest')


 %% Analysis on the  Sureal vs ESQR weights on the Netflix pub db
    data=load('netflix_votes.mat');
    data=struct2array(data);

    %SUREAL 
    [Q_SUREAL,b,inc,CI_SURAL]=perform_SUREAL(data,10^(-8));
    W_sureal=(1./(inc.^2)*ones(1,size(data,1)))';
    for i=1:size(data,1)
        W_sureal(i,:)= W_sureal(i,:)/sum(W_sureal(i,:));
    end
    figure
    h=imagesc(W_sureal);
    xticks(1:26)
    yticks([1 10:10:70])
    xlabel('Subjects')
    ylabel('Stimuli')
    c=colorbar;
    c.Limits = [0  .07];

    % ESQR
    [Q_ESQR,~,~,W]=run_ESQR(data);
    figure
    h=imagesc(W);
    xticks(1:26)
    yticks([1 10:10:70])
    xlabel('Subjects')
    ylabel('Stimuli')
    c.Limits = [0  .07];






