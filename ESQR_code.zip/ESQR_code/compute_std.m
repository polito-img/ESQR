function stds=compute_std(prob)
         for i=1:size(prob,1)
             stds(i)=sqrt([1 4 9 16 25]*(prob(i,:))'-([1 2 3 4 5]*(prob(i,:))')^2);
         end
end