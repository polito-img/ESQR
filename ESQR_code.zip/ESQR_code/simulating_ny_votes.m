function [V,CI,q]=simulating_ny_votes(seed)
      rng(100)
      N_pvs=100;
      N_subject=25;
      V=zeros(N_pvs,N_subject);

       q=1.5+3*rand(1,N_pvs);


      
      a=.2*(-q.^2+6*q-5);
      %CI=[q' q']+ [-1.96*a'/sqrt(N_subject) 1.96*a'/sqrt(N_subject)];
      
      for i=1:N_pvs
          CI(i,:)=[q(i) q(i)]+ [-1.96*a(i)/sqrt(N_subject) 1.96*a(i)/sqrt(N_subject)];
      end


      for i=1:20
          rng(seed*i)
          for j=1:N_pvs
              p_err=0.01;
              e=binornd(1,1-p_err);
              r=normrnd(q(j),a(j))*e + randsample(5,1)*(1-e);
              V(j,i)=round_to_ACR(r);
          end
      end

      for i=21:25
           rng(seed*i)
          for j=1:N_pvs
              p_err=(0.6+0.4*rand *(.25*(-q(j).^2+6*q(j)-5)));
              e=binornd(1,1-p_err);
              r=normrnd(q(j),a(j))*e + randsample(5,1)*(1-e);
              V(j,i)=round_to_ACR(r);
          end
      end
end

function r=round_to_ACR(x)
 if x<=1
     r=1;
 elseif x>1 && x<=5
     r=round(x);
 else
     r=5;
 end
end