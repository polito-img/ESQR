function [mos, rej_subj]=perform_BT_500(X,alpha,beta)

         S=size(X,2);
         rej_subj=zeros(1,S);
         P=zeros(1,S);
         Q=zeros(1,S);
         E=size(X,1);
         
         for i=1:E
             mu_i=mean(X(i,:));
             sigma_i=std(X(i,:));
             m_4=1/S*(sum((X(i,:)-mu_i).^4));
             m_2=1/S*(sum((X(i,:)-mu_i).^2));
             K_i=m_4/((m_2))^2;
             e_i=2*(K_i>=2 & K_i<=4)+sqrt(20)*(~(K_i>2 & K_i<4));
             
             for j=1:S
                 P(j)=P(j)+(X(i,j)>=(mu_i+e_i*sigma_i));
                 Q(j)=Q(j)+(X(i,j)<=(mu_i-e_i*sigma_i));
             end             
         end
      
        
         for j=1:S
             rej_subj(j)=(((P(j)+Q(j))/E)>=alpha & (abs(P(j)-Q(j))/((P(j)+Q(j))))<beta);
         end
         mos=mean(X(:,~rej_subj),2); 
end
