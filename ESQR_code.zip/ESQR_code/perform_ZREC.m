function [Q,Avg_CI_size,CI_ZREC]=perform_ZREC(O)

% O is the matrix of opinion scores
n_pvs=size(O,1);
n_sub=size(O,2);
m=(mean(O,2));
s=(std(O',0))'+eps;
I=ones(1,n_sub);
Z=(O-m*I)./(s*I);

% compute the biases
B=mean(Z,1);

% compute inconsistencies
for i=1:n_sub
    C(i)=sqrt(mean((Z(:,i)-B(i)).^2));
end

%C=std(Z);

U=O-s*B;
W=(C.^(-2))/sum((C.^(-2)));
Q=U*W';

         % compute CI avg size
        S=sqrt(  (n_sub/(n_sub-1))*  (((U-Q*ones(1,size(U,2))).^2)*W'));
        
        Avg_CI_size=mean(2*1.96*S/sqrt(n_sub) );
        
        CI_ZREC=[Q-1.96*S/sqrt(n_sub), Q+1.96*S/sqrt(n_sub)];
        
end