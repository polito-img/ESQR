function [quality, bias, inc, quality_CI] = perform_SUREAL_CS(Votes,threshold)

% This function run the sureal software 
% Votes is the matrix of observers rates
% the authors suggest to set the thresold=10^(-8)

  stop=0;
  quality=nanmean(Votes,2);
  bias=(nanmean((Votes-quality*ones(1,size(Votes,2)))))';
  eps=zeros(size(Votes));
  
  while ~stop
       quality_prev=quality;
       for i=1:size(Votes,1)
           for j=1:size(Votes,2)
               eps(i,j)=Votes(i,j)-quality(i)-bias(j);
           end
       end
       inc=(nanstd(eps))';

       % find the subjects that rated each seq and compute the weights
       for ii=1:size(Votes,1)
           id=isnan(Votes(i,:));
           weights=(1./((inc(~id)).^2))/sum((1./((inc(~id)).^2)));
           quality(i)=(Votes(i,~id)- (bias(~id))')*weights;
       end

       bias=(nanmean((Votes-quality*ones(1,size(Votes,2)))))';
       stop=norm(quality_prev-quality)<threshold;
  end
   
  quality_CI=[];
  for i=1:size(Votes,1)
      id=isnan(Votes(i,:));
      quality_CI(i,:)=quality(i)+[-1,1]*1.96*( 1/sqrt( sum((inc(~id)).^(-2)) ) );
  end
end