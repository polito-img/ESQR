function corr_coef=fisher_z_transformation_cs(V)
             z=atanh(V);
             z=mean(z);
             corr_coef=tanh(z);              
end