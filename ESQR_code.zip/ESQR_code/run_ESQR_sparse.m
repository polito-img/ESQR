function [q,Avg_CI_size,CIs]=run_ESQR_sparse(X)
         n=size(X,2);
         weights=compute_ESQR_sparse_Weights(X);

         % set nan to 0 so that they do not count in the computations
         weights(isnan(X))=0;
         X(isnan(X))=0;
         q=diag(X*weights');

         % compute CI avg size
        S=sqrt((n/(n-1))*  diag(((X-q*ones(1,size(X,2))).^2)*weights'));
        nun_ratings=sum(X~=0,2);
        CIs=[q, q]+[-ones(size(q)),ones(size(q))].*[1.96*S./sqrt(nun_ratings),1.96*S./sqrt(nun_ratings)];
        Avg_CI_size=mean(2*1.96*S./sqrt(nun_ratings) );     
end


function w=compute_ESQR_sparse_Weights(X)

        % getting the number of annotators and objects
        num_annotators=size(X,2);
        num_objects=size(X,1);
         
        % compute the observed distribution of opinion scores to use as
        % estimate of the P_V_i distributions 
         prob=zeros(num_objects,5);
         for i=1:num_objects
             for j=1:num_annotators
                 if ~isnan(X(i,j))
                     prob(i,:)=prob(i,:)+(1/sum(~isnan(X(i,:))))*to_dist(X(i,j));                    
                 end
             end
         end

        % how surprizing is each rating given the estimate of the ground trth distribution
        P_hat=NaN(num_objects,num_annotators); 
        for ii=1:num_annotators
            for jj=1:num_objects
                if ~isnan(X(jj,ii))
                    P_hat(jj,ii)=-log(prob(jj,X(jj,ii)));  
                end
            end
        end
        Relaibility=P_hat.^(-1);
     
        % compute the weights as the inverse of the surprize
        w=zeros(num_objects,num_annotators);
        for i=1:num_objects
            w(i,:)= (Relaibility(i,:))/nansum((Relaibility(i,:)));
        end
end

%%
function d=to_dist(vote)
         d=zeros(1,5);
         d(vote)=1;
end